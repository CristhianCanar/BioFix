<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Empresa extends Model
{
    use HasFactory;

    protected $table = 'empresas';
    protected $fillable = [
        'municipio_id',
        'nit',
        'razon_social',
        'numero_contrato',
        'direccion',
        'telefono',
    ];

    public function municipios()
    {
        return $this->belongsTo(Municipio::class, 'municipio_id', 'id_municipio');
    }
}
