<div class="card">
    <div class="card-body table-responsive">
        <div class="<?php echo e((isset($noResponsive)) ? '' : 'table-responsive'); ?>">
            <table class="table table-hover" id="<?php echo e((isset($id)) ? $id : ''); ?>">
                <thead>
                    <?php if(isset($theadTr)): ?>
                    <?php echo e($theadTr); ?>

                    <?php endif; ?>
                    <tr>
                        <?php if(isset($thead)): ?>
                        <?php echo e($thead); ?>

                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($tbody) && $tbody != ""): ?>
                    <?php echo e($tbody); ?>

                    <?php else: ?>
                    <tr class="text-center">
                        <td colspan="100%" scope="row"><i class="fas fa-info-circle"></i> No se encontraron registros.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                </tfoot>
            </table>
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/components/table.blade.php ENDPATH**/ ?>