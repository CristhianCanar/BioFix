<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <h1 class="text-center"><b>Equipos dados de baja</b></h1>

        <div class="mt-4">
            <?php $__env->startComponent('components.table'); ?>
                <?php $__env->slot('thead'); ?>
                    <th>N°</th>
                    <th scope="col">Equipo</th>
                    <th scope="col">Serie</th>
                    <th scope="col">Fecha</th>
                    <th scope="col">Observaciones</th>
                    <th scope="col" class="text-right">Acciones</th>
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('tbody'); ?>
                    <?php $__currentLoopData = $bajasEquipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bajasEquipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td class="text-truncate"><?php echo e($bajasEquipo->equipo->nombre); ?></td>
                            <td class="text-truncate"><?php echo e($bajasEquipo->equipo->serie); ?></td>
                            <td class="text-truncate"><?php echo e($bajasEquipo->baja_fecha); ?></td>
                            <td class="text-truncate"><?php echo e($bajasEquipo->observaciones); ?></td>
                            <td>
                                <div class="row float-right justify-content-end" style="font-size: 20px">
                                    <div>
                                        <a href="<?php echo e(route('unsubscribe.show', $bajasEquipo->id)); ?>" style="color: #fa8c15;">
                                            <i class="la icon-eye" data-toggle="tooltip" title="Ver baja de equipo"></i>
                                        </a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->endSlot(); ?>
                <span> Total registros <b><?php echo e($bajasEquipos->total()); ?></b></span>
                <span class="float-right"><?php echo e($bajasEquipos->links()); ?></span>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/dar_de_baja_equipos/manage.blade.php ENDPATH**/ ?>