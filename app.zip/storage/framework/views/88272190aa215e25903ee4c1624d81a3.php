<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <h1 class="text-center"><b>Gestionar equipos</b></h1>

        <div class="mt-4">
            <?php $__env->startComponent('components.table'); ?>
                <?php $__env->slot('thead'); ?>
                    <th>N°</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Serie</th>
                    <th scope="col">Marca</th>
                    <th scope="col">Empresa</th>
                    <th scope="col">Estado</th>
                    <th scope="col" class="text-right">Acciones</th>
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('tbody'); ?>
                    <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td class="text-truncate"><?php echo e($equipo->nombre); ?></td>
                            <td class="text-truncate"><?php echo e($equipo->serie); ?></td>
                            <td class="text-truncate"><?php echo e($equipo->marca); ?></td>
                            <td class="text-truncate"><?php echo e($equipo->empresas->razon_social); ?></td>
                            <td class="text-truncate"><?php echo e($equipo->estado ? 'Activo' : 'Inactivo'); ?></td>
                            <td>
                                <div class="row float-right justify-content-end" style="font-size: 20px">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('equipo_ver')): ?>
                                        <div class="col-2">
                                            <a href="<?php echo e(route('equipos.show', $equipo->id)); ?>" style="color: #fa8c15;">
                                                <i class="la icon-eye" data-toggle="tooltip" title="Ver equipo"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mantenimiento_ver')): ?>
                                        <div class="col-2">
                                            <a href="<?php echo e(route('mantenimientos.show.equipo', $equipo->id)); ?>" style="color: #fa8c15;">
                                                <i class="la icon-settings" data-toggle="tooltip" title="Ver mantenimientos"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('equipo_editar')): ?>
                                        <div class="col-2">
                                            <a href="<?php echo e(route('equipos.edit', $equipo->id)); ?>" style="color: #5C55BF;">
                                                <i class="la icon-note" data-toggle="tooltip" title="Editar equipo"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('observacion_dar_baja_registrar')): ?>
                                        <div class="col-2">
                                            <a href="<?php echo e(route('unsubscribe.create.observation', $equipo->id)); ?>" style="color: #5C55BF;">
                                                <i class="la icon-arrow-down-circle" data-toggle="tooltip" title="Agregar observación para dar de baja"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dar_baja_registrar')): ?>
                                        <div class="col-2">
                                            <a href="<?php echo e(route('unsubscribe.create', $equipo->id)); ?>" style="color: #f44336;">
                                                <i class="la icon-close" data-toggle="tooltip" title="Dar de baja equipo"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('equipo_eliminar')): ?>
                                        <div class="col-2">
                                            <form action="<?php echo e(route('equipos.destroy', $equipo->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-light p-0"
                                                    onclick="return confirm('Seguro que desea eliminar el registro del equipo?')">
                                                    <i class="la icon-trash" data-toggle="tooltip" data-placement="top"
                                                        title="Eliminar equipo" style="font-size: 20px; color: #f44336;"></i>
                                                </button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->endSlot(); ?>
                <span> Total registros <b><?php echo e($equipos->total()); ?></b></span>
                <span class="float-right"><?php echo e($equipos->links()); ?></span>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/equipos/manage.blade.php ENDPATH**/ ?>