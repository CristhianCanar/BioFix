<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="col-10 mt-4 mx-auto">
            <?php $__env->startComponent('components.card-form', ['title' => 'Detalles baja de equipo']); ?>
                <div class="form-group">
                    <label class="form-label" for="departamento_id">Nombre Equipo</label>
                    <p><?php echo e($bajaEquipo->equipo->nombre); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="municipio_id">Serie</label>
                    <p><?php echo e($bajaEquipo->equipo->serie); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Modelo</label>
                    <p><?php echo e($bajaEquipo->equipo->modelo); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Marca</label>
                    <p><?php echo e($bajaEquipo->equipo->marca); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="departamento_id">Fecha de baja</label>
                    <p><?php echo e($bajaEquipo->baja_fecha); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="municipio_id">Motivo de baja</label>
                    <p><?php echo e($bajaEquipo->baja_motivo); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Evaluación técnica</label>
                    <p><?php echo e($bajaEquipo->evaluacion_tecnica); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Evaluación clinica</label>
                    <p><?php echo e($bajaEquipo->evaluacion_clinica); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Observaciones</label>
                    <p><?php echo e($bajaEquipo->observaciones); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Cláusula</label>
                    <p><?php echo e($bajaEquipo->clausula); ?></p>
                </div>

                <div class="form-group mt-4 mx-auto">
                    <a href="<?php echo e(route('unsubscribe.index')); ?>" class="btn btn-default btn-block"><i
                            class="la icon-logout mr-3"></i>Regresar</a>
                </div>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/dar_de_baja_equipos/show.blade.php ENDPATH**/ ?>