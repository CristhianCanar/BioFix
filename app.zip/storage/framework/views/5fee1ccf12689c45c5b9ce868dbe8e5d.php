<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <h1 class="text-center"><b>Gestionar usuarios</b></h1>
        <div class="mt-4">
            <?php $__env->startComponent('components.table'); ?>
                <?php $__env->slot('thead'); ?>
                    <th>N°</th>
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Email</th>
                    <th scope="col">Rol</th>
                    <th scope="col" class="text-right">Acciones</th>
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('tbody'); ?>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td class="text-truncate"><?php echo e($usuario->nombre); ?></td>
                            <td class="text-truncate"><?php echo e($usuario->apellido); ?></td>
                            <td class="text-truncate"><?php echo e($usuario->email); ?></td>
                            <td class="text-truncate"><?php echo e(str_replace('[','',str_replace(']','',$usuario->getRoleNames()))); ?></td>
                            <td>
                                <div class="row float-right justify-content-end" style="font-size: 20px">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users_editar')): ?>
                                        <div class="col-3">
                                            <a href="<?php echo e(route('usuarios.edit', $usuario->id)); ?>"
                                                style="color: #5C55BF;">
                                                <i class="la icon-note" data-toggle="tooltip"
                                                    title="Editar usuario"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-3">
                                        <a href="<?php echo e(route('usuarios.show', $usuario->id)); ?>"
                                            style="color: #fa8c15;">
                                            <i class="la icon-eye" data-toggle="tooltip"
                                                title="Ver usuario"></i>
                                        </a>
                                    </div>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users_eliminar')): ?>
                                        <div class="col-3 mr-1">
                                            <form action="<?php echo e(route('usuarios.destroy', $usuario->id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-light bg-inherit p-0"
                                                    onclick="return confirm('Seguro que desea eliminar el usuario?')">
                                                    <i class="la icon-trash" data-toggle="tooltip"
                                                        data-placement="top" title="Eliminar usuario"
                                                        style="font-size: 20px; color: #f44336;"></i>
                                                </button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->endSlot(); ?>
                <span> Total registros <b><?php echo e($usuarios->total()); ?></b></span>
                <span class="float-right"><?php echo e($usuarios->links()); ?></span>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/usuarios/manage.blade.php ENDPATH**/ ?>