<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="col-10 mt-4 mx-auto">
            <?php $__env->startComponent('components.card-form', ['title' => 'Registrar mantenimiento', 'show' => false]); ?>
                <form action="<?php echo e(route('mantenimientos.store')); ?>" method="POST" enctype="multipart/form-data"
                    class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12">
                            <label class="form-label" for="text">Seleccione equipo ( Serie - Nombre - Modelo )
                                <span class="text-danger">*</span>
                            </label>
                            <select class="form-control" name="equipo_id" id="equipo_id" required>
                                <option value="" selected disabled>Seleccione...</option>
                                <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($equipo->id); ?>">
                                        <?php echo e($equipo->serie); ?> - <?php echo e($equipo->nombre); ?> - <?php echo e($equipo->modelo); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['equipo_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Fecha mantenimiento
                                <span class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php $__errorArgs = ['fecha_mantenimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="fecha_mantenimiento" id="fecha_mantenimiento" value="<?php echo e(old('fecha_mantenimiento')); ?>"
                                required>
                            <?php $__errorArgs = ['fecha_mantenimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center mt-4">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['retiro_equipo_IPS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="retiro_equipo_IPS" id="retiro_equipo_IPS"
                                    <?php echo e(old('retiro_equipo_IPS') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">¿Retiro equipo de IPS? <span class="text-danger">*</span></span>
                            </label>
                            <?php $__errorArgs = ['retiro_equipo_IPS'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center mt-4">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['equipo_funcionando'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="equipo_funcionando" id="equipo_funcionando"
                                    <?php echo e(old('equipo_funcionando') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">¿El equipo queda en funcionamiento? <span
                                        class="text-danger">*</span></span>
                            </label>
                            <?php $__errorArgs = ['equipo_funcionando'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Verificación de bioseguridad</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-8 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['vb_pregunta_uno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="vb_pregunta_uno" id="vb_pregunta_uno" <?php echo e(old('vb_pregunta_uno') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿El equipo médico se entrega limpio y desinfectado para realizar
                                    la actividad de mantenimiento?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['vb_pregunta_uno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-8 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['vb_pregunta_dos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="vb_pregunta_dos" id="vb_pregunta_dos" <?php echo e(old('vb_pregunta_dos') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿El mantenimiento cuenta con los implementos de dotación necesarios para garantizar la
                                    seguridad?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['vb_pregunta_dos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Repuestos</b></h2>
                    </div>
                    <div class="row">
                        <div class="col-10">
                            <div id="repuestos-container">
                                <div class="form-row justify-content-center repuesto">
                                    <div class="form-group col-3 col-md-3">
                                        <label class="form-label" for="text">
                                            Fecha reporte
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="date" class="form-control" name="repuestos[0][fecha_reporte]">
                                    </div>
                                    <div class="form-group col-4 col-md-3">
                                        <label class="form-label" for="text">
                                            Nombre repuesto
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control" name="repuestos[0][repuesto]" maxlength="100">
                                    </div>
                                    <div class="form-group col-4 col-md-3">
                                        <label class="form-label" for="text">
                                            Nombre proveedor
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="text" class="form-control" name="repuestos[0][proveedor]" maxlength="100">
                                    </div>
                                    <div class="form-group col-2 col-md-3">
                                        <label class="form-label" for="text">
                                            Cantidad
                                            <span class="text-danger">*</span>
                                        </label>
                                        <input type="number" class="form-control" name="repuestos[0][cantidad]" min="1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-2 mt-4">
                            <div class="row">
                                <div class="col-2 col-md-3">
                                    <a class="text-decoration-none" id="add-repuesto" style="cursor: pointer;">
                                        <i class="fas fa-plus-circle text-primary" style="font-size: 1.5rem;"></i>
                                    </a>
                                </div>
                                <div class="col-2 col-md-3">
                                    <a class="text-decoration-none" id="remove-repuesto" style="cursor: pointer;">
                                        <i class="fas fas fa-trash text-danger" style="font-size: 1.5rem;"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center  mt-4">
                        <h2><b>Verificación de funcionamiento</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['vf_carcasa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="vf_carcasa" id="vf_carcasa" <?php echo e(old('vf_carcasa') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿El equipo tiene carcasa?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['vf_carcasa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['vf_etiquetado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="vf_etiquetado" id="vf_etiquetado" <?php echo e(old('vf_etiquetado') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿El equipo tiene etiquetado?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['vf_etiquetado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['vf_estructura_soporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="vf_estructura_soporte" id="vf_estructura_soporte"
                                    <?php echo e(old('vf_estructura_soporte') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿El equipo tiene estructura de soporte?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['vf_estructura_soporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['vf_integridad_rosca_tapa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="vf_integridad_rosca_tapa" id="vf_integridad_rosca_tapa"
                                    <?php echo e(old('vf_integridad_rosca_tapa') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿La integridad de la rosca es correcta?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['vf_integridad_rosca_tapa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['vf_revision_limpieza_tanque'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="vf_revision_limpieza_tanque" id="vf_revision_limpieza_tanque"
                                    <?php echo e(old('vf_revision_limpieza_tanque') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿Revisión de la limpieza de tanque?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['vf_revision_limpieza_tanque'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['vf_revision_fuga_gas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="vf_revision_fuga_gas" id="vf_revision_fuga_gas"
                                    <?php echo e(old('vf_revision_fuga_gas') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿Revisión fuga de gas?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['vf_revision_fuga_gas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['vf_condicion_entorno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="vf_condicion_entorno" id="vf_condicion_entorno"
                                    <?php echo e(old('vf_condicion_entorno') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿Condiciones de entorno (Humedad, temperatura)?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['vf_condicion_entorno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Mantenimiento</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['m_limpieza_externa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="m_limpieza_externa" id="m_limpieza_externa"
                                    <?php echo e(old('m_limpieza_externa') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿Limpieza externa?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['m_limpieza_externa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['m_limpieza_interna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="m_limpieza_interna" id="m_limpieza_interna"
                                    <?php echo e(old('m_limpieza_interna') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿Limpieza interna?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['m_limpieza_interna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['m_ajustes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="m_ajustes" id="m_ajustes" <?php echo e(old('m_ajustes') ? 'checked' : ''); ?>>
                                <span class="form-check-sign">
                                    ¿Ajustes?
                                    <span class="text-danger">*</span>
                                </span>
                            </label>
                            <?php $__errorArgs = ['m_ajustes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Tiempo usado (minutos) <span
                                    class="text-danger">*</span></label>
                            <input type="number" class="form-control <?php $__errorArgs = ['m_tiempo_usado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="m_tiempo_usado" id="m_tiempo_usado" value="<?php echo e(old('m_tiempo_usado')); ?>"
                                min="1" required>
                            <?php $__errorArgs = ['m_tiempo_usado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-row justify-content-center">
                        <h2><b>Responsable</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <p><b>Quien recibe y compromete a realizar la actividad necesaria para que el equipo este limpio y
                                desinfectado</b></p>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12">
                            <label class="form-label" for="text">Seleccione responsable <span
                                    class="text-danger">*</span></label>
                            <select class="form-control" name="responsable_id" id="responsable_id" required>
                                <option value="" selected disabled>Seleccione...</option>
                                <?php $__currentLoopData = $responsables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $responsable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($responsable->id); ?>">
                                        <?php echo e($responsable->nombre); ?> <?php echo e($responsable->apellido); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['responsable_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="mt-4 d-flex justify-content-between mx-2">
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-default col-5" type="button">
                            <i class="la icon-close mr-2"></i> Cancelar
                        </a>

                        <button class="btn btn-success col-5" type="submit">
                            <i class="la icon-check mr-2"></i> Registrar
                        </button>
                    </div>

                </form>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            let index = 1;

            $('#add-repuesto').click(function() {
                $('#repuestos-container').append(
                    `<div class="form-row justify-content-center repuesto">
                        <div class="form-group col-3 col-md-3">
                            <label class="form-label" for="text">
                                Fecha reporte
                                <span class="text-danger">*</span>
                            </label>
                            <input type="date" class="form-control" name="repuestos[${index}][fecha_reporte]">
                        </div>
                        <div class="form-group col-4 col-md-3">
                            <label class="form-label" for="text">
                                Nombre repuesto
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="repuestos[${index}][repuesto]">
                        </div>
                        <div class="form-group col-4 col-md-3">
                            <label class="form-label" for="text">
                                Nombre proveedor
                                <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="repuestos[${index}][proveedor]">
                        </div>
                        <div class="form-group col-2 col-md-3">
                            <label class="form-label" for="text">
                                Cantidad
                                <span class="text-danger">*</span>
                            </label>
                            <input type="number" class="form-control" name="repuestos[${index}][cantidad]" min="1">
                        </div>
                    </div>`
                );
                index++;
            });

            $('#remove-repuesto').click(function() {
                if (index > 1) {
                    $('#repuestos-container .repuesto:last').remove();
                    index--;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/mantenimientos/register.blade.php ENDPATH**/ ?>