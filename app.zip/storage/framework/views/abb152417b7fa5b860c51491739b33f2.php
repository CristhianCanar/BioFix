<div class="card shadow-sm">
	<?php if(isset($title)): ?>
		<div class="card-header bg-dark2 rounded-top">
            <h1 class="text-white"><?php echo e($title); ?></h1>
            <?php if(isset($show)): ?>
                <?php if(!$show): ?>
                    <span class="text-danger">* Indica que la pregunta es obligatoria</span>
                <?php endif; ?>
            <?php endif; ?>
  		</div>
  	<?php endif; ?>

	<div class="card-body">
		<?php echo e($slot); ?>

	</div>
</div>
<?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/components/card-form.blade.php ENDPATH**/ ?>