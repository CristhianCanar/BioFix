<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="col-10 mt-4 mx-auto">
            <?php $__env->startComponent('components.card-form', [
                'title' => 'Registrar observación para dar de baja al equipo',
                'show' => false,
            ]); ?>
                <form action="<?php echo e(route('unsubscribe.store.observation', ['equipoId' => $equipo->id])); ?>" method="POST"
                    class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="form-group">
                        <h4><b>Datos del equipo</b></h4>
                        <div class="row justify-content-around">
                            <div>
                                <strong class="text-dark">Nombre:</strong>
                                <p class="text-muted"><?php echo e($equipo->nombre); ?></p>
                            </div>
                            <div>
                                <strong class="text-dark">Serie:</strong>
                                <p class="text-muted"><?php echo e($equipo->serie); ?></p>
                            </div>
                            <div>
                                <strong class="text-dark">Modelo:</strong>
                                <p class="text-muted"><?php echo e($equipo->modelo); ?></p>
                            </div>
                            <div>
                                <strong class="text-dark">Marca:</strong>
                                <p class="text-muted"><?php echo e($equipo->marca); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col">
                            <label class="form-label" for="text">Observaciones para dar de baja al equipo</label>
                            <textarea class="form-control <?php $__errorArgs = ['observacion_baja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="observacion_baja"
                                placeholder="No hay observaciones registradas..." id="observacion_baja" required><?php echo e($equipo->observacion_baja != null ? $equipo->observacion_baja : ''); ?></textarea>

                            <?php $__errorArgs = ['observacion_baja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="mt-4 d-flex justify-content-between mx-2">
                        <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-default col-5" type="button">
                            <i class="la icon-close mr-2"></i> Cancelar
                        </a>
                        <button class="btn btn-success col-5" type="submit">
                            <i class="la icon-check mr-2"></i> Registrar
                        </button>
                    </div>
                </form>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/dar_de_baja_equipos/register_observation.blade.php ENDPATH**/ ?>