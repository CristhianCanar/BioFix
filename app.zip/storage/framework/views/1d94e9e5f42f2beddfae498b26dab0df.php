<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="col-10 mt-4 mx-auto">
            <?php $__env->startComponent('components.card-form', ['title' => 'Detalles empresa']); ?>
                <div class="form-group">
                    <label class="form-label" for="departamento_id">Departamento</label>
                    <p><?php echo e($empresa->municipios->departamentos->nombre); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="municipio_id">Municipio</label>
                    <p><?php echo e($empresa->municipios->nombre); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">NIT</label>
                    <p><?php echo e($empresa->nit); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Razón social</label>
                    <p><?php echo e($empresa->razon_social); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Número de contrato</label>
                    <p><?php echo e($empresa->numero_contrato); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Dirección</label>
                    <p><?php echo e($empresa->direccion); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Teléfono</label>
                    <p><?php echo e($empresa->telefono); ?></p>
                </div>

                <div class="form-group mt-4 mx-auto">
                    <a href="<?php echo e(route('empresas.index')); ?>" class="btn btn-danger w-100 text-white"><i class="la icon-logout mr-3"></i>Regresar</a>
                </div>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/empresas/show.blade.php ENDPATH**/ ?>