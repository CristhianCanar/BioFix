<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="col-10 mt-4 mx-auto">
            <?php $__env->startComponent('components.card-form', ['title' => 'Actualizar equipo', 'show' => false]); ?>
                <form action="<?php echo e(route('equipos.update', ['equipo' => $equipo->id])); ?>" method="POST"
                    enctype="multipart/form-data" class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-row justify-content-center">
                        <h2><b>Datos básicos</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="text">Nombre <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre"
                                id="nombre" value="<?php echo e($equipo->nombre); ?>" maxlength="200" required>
                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="text">Serie <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['serie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="serie"
                                id="serie" value="<?php echo e($equipo->serie); ?>" maxlength="100" required>
                            <?php $__errorArgs = ['serie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="text">Servicio</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['servicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="servicio"
                                id="servicio" value="<?php echo e($equipo->servicio); ?>" maxlength="200">
                            <?php $__errorArgs = ['servicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="text">Marca <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="marca"
                                id="marca" value="<?php echo e($equipo->marca); ?>" maxlength="100" required>
                            <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="text">Responsable del equipo <span
                                    class="text-danger">*</span></label>
                            <select class="form-control" name="responsable_id" id="responsable_id" required>
                                <option value="<?php echo e($equipo->responsable_id); ?>" selected><?php echo e($equipo->responsables->nombre); ?>

                                    <?php echo e($equipo->responsables->apellido); ?></option>
                                <?php $__currentLoopData = $responsables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $responsable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($responsable->id); ?>">
                                        <?php echo e($responsable->nombre); ?> <?php echo e($responsable->apellido); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['responsable_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="text">Ubicación <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['ubicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ubicacion"
                                id="ubicacion" value="<?php echo e($equipo->ubicacion); ?>" maxlength="200" required>
                            <?php $__errorArgs = ['ubicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Código ECRI <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['codigo_ECRI'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="codigo_ECRI" id="codigo_ECRI" value="<?php echo e($equipo->codigo_ECRI); ?>" maxlength="100"
                                required>
                            <?php $__errorArgs = ['codigo_ECRI'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Empresa <span class="text-danger">*</span></label>
                            <select class="form-control" name="empresa_id" id="empresa_id" required>
                                <option value="<?php echo e($equipo->empresa_id); ?>" selected><?php echo e($equipo->empresas->razon_social); ?>

                                </option>
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($empresa->id); ?>">
                                        <?php echo e($empresa->razon_social); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['empresa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Número documento</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['numero_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="numero_documento" id="numero_documento" value="<?php echo e($equipo->numero_documento); ?>"
                                maxlength="100" required>
                            <?php $__errorArgs = ['numero_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-4 d-flex align-items-center mt-4">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['calibracion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="calibracion" id="calibracion" onclick="cambiarEstadoSelectFrecCalibracion()"
                                    <?php echo e($equipo->calibracion ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Necesita calibración <span class="text-danger">*</span></span>
                            </label>
                            <?php $__errorArgs = ['calibracion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Frecuencia calibración <span
                                    class="text-danger">*</span></label>
                            <select class="form-control" name="frecuencia_calibracion" id="frecuencia_calibracion"
                                <?php echo e(!$equipo->calibracion ? 'disabled' : ''); ?>>
                                <option value="<?php echo e($equipo->frecuencia_calibracion); ?>" selected>
                                    <?php echo e($equipo->frecuencia_calibracion); ?></option>
                                <?php $__currentLoopData = $frecuencias_calibracion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frecuencia_calibracion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($frecuencia_calibracion); ?>">
                                        <?php echo e($frecuencia_calibracion); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['frecuencia_calibracion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Frecuencia mantenimiento <span
                                    class="text-danger">*</span></label>
                            <select class="form-control" name="frecuencia_mantenimiento" id="frecuencia_mantenimiento"
                                required>
                                <option value="<?php echo e($equipo->frecuencia_mantenimiento); ?>" selected>
                                    <?php echo e($equipo->frecuencia_mantenimiento); ?>

                                </option>
                                <?php $__currentLoopData = $frecuencias_mantenimiento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frecuencia_mantenimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($frecuencia_mantenimiento); ?>">
                                        <?php echo e($frecuencia_mantenimiento); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['frecuencia_mantenimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="text">Modelo <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="modelo"
                                id="modelo" value="<?php echo e($equipo->modelo); ?>" maxlength="100">
                            <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="text">Activo fijo <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['activo_fijo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="activo_fijo" id="activo_fijo" value="<?php echo e($equipo->activo_fijo); ?>" maxlength="100"
                                required>
                            <?php $__errorArgs = ['activo_fijo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="text">Imagen del equipo</label>
                            <?php if($equipo->url_imagen): ?>
                                <div class="d-flex">
                                    <img class="img-fluid rounded w-25 mx-auto m-2"
                                        src="<?php echo e(URL::asset('storage/' . $equipo->url_imagen)); ?> ">
                                </div>
                            <?php endif; ?>
                            <input type="file" class="form-control <?php $__errorArgs = ['url_imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="url_imagen" id="url_imagen" value="<?php echo e($equipo->url_imagen); ?>" accept="image/*">
                            <?php $__errorArgs = ['url_imagen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Registro histórico</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Registro INVIMA <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['h_reg_INVIMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="h_reg_INVIMA" id="h_reg_INVIMA" value="<?php echo e($equipo->h_reg_INVIMA); ?>" maxlength="100"
                                required>
                            <?php $__errorArgs = ['h_reg_INVIMA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Registro de importación <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['h_reg_importacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="h_reg_importacion" id="h_reg_importacion" value="<?php echo e($equipo->h_reg_importacion); ?>"
                                maxlength="100" required>
                            <?php $__errorArgs = ['h_reg_importacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Registro FDA <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['h_reg_FDA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="h_reg_FDA" id="h_reg_FDA" value="<?php echo e($equipo->h_reg_FDA); ?>" maxlength="100" required>
                            <?php $__errorArgs = ['h_reg_FDA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Sitio web <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['h_url_sitio_web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="h_url_sitio_web" id="h_url_sitio_web" value="<?php echo e($equipo->h_url_sitio_web); ?>"
                                maxlength="200" required>
                            <?php $__errorArgs = ['h_url_sitio_web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Dirección proveedor <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['h_direccion_proveedor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="h_direccion_proveedor" id="h_direccion_proveedor"
                                value="<?php echo e($equipo->h_direccion_proveedor); ?>" maxlength="100" required>
                            <?php $__errorArgs = ['h_direccion_proveedor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Teléfono <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['h_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="h_telefono" id="h_telefono" value="<?php echo e($equipo->h_telefono); ?>" maxlength="20"
                                required>
                            <?php $__errorArgs = ['h_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="departamento_id">Departamento <span
                                    class="text-danger">*</span></label>
                            <select class="form-control" name="departamento_id" id="departamento_id" required>
                                <option value="<?php echo e($equipo->municipios->departamentos->id_departamento); ?>" selected>
                                    <?php echo e($equipo->municipios->departamentos->nombre); ?>

                                </option>
                                <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($departamento->id_departamento); ?>">
                                        <?php echo e($departamento->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['departamento_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="municipio_id">Municipio <span class="text-danger">*</span></label>
                            <select class="form-control" name="municipio_id" id="municipio_id" required
                                src=<?php echo e(route('empresas.get_municipios', '#')); ?>>
                                <option value="<?php echo e($equipo->municipio_id); ?>" selected><?php echo e($equipo->municipios->nombre); ?>

                                </option>
                            </select>
                            <?php $__errorArgs = ['municipio_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Vida útil <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['h_vida_util'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="h_vida_util" id="h_vida_util" value="<?php echo e($equipo->h_vida_util); ?>" maxlength="20"
                                required>
                            <?php $__errorArgs = ['h_vida_util'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Costo <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['h_costo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="h_costo"
                                id="h_costo" value="<?php echo e($equipo->h_costo); ?>" maxlength="50" required>
                            <?php $__errorArgs = ['h_costo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Garantía <span class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['h_garantia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="h_garantia" id="h_garantia" value="<?php echo e($equipo->h_garantia); ?>" maxlength="50"
                                required>
                            <?php $__errorArgs = ['h_garantia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="form-row justify-content-center">
                        <h2><b>Fuentes de alimentación</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['fa_electrica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="fa_electrica" id="fa_electrica" <?php echo e($equipo->fa_electrica ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Eléctrica </span>
                            </label>
                            <?php $__errorArgs = ['fa_electrica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['fa_bateria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="fa_bateria" id="fa_bateria" <?php echo e($equipo->fa_bateria ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Batería</span>
                            </label>
                            <?php $__errorArgs = ['fa_bateria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['fa_regulada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="fa_regulada" id="fa_regulada" <?php echo e($equipo->fa_regulada ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Regulada</span>
                            </label>
                            <?php $__errorArgs = ['fa_regulada'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Registro de apoyo técnico</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['at_medico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="at_medico" id="at_medico" <?php echo e($equipo->at_medico ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Médico</span>
                            </label>
                            <?php $__errorArgs = ['at_medico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['at_apoyo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="at_apoyo" id="at_apoyo" <?php echo e($equipo->at_apoyo ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Apoyo</span>
                            </label>
                            <?php $__errorArgs = ['at_apoyo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['at_basico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="at_basico" id="at_basico" <?php echo e($equipo->at_basico ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Básico</span>
                            </label>
                            <?php $__errorArgs = ['at_basico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['at_transporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="at_transporte" id="at_transporte" <?php echo e($equipo->at_transporte ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Transporte</span>
                            </label>
                            <?php $__errorArgs = ['at_transporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['at_clase_I'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="at_clase_I" id="at_clase_I" <?php echo e($equipo->at_clase_I ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Clase I</span>
                            </label>
                            <?php $__errorArgs = ['at_clase_I'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['at_clase_I_IA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="at_clase_I_IA" id="at_clase_I_IA" <?php echo e($equipo->at_clase_I_IA ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Clase I IA</span>
                            </label>
                            <?php $__errorArgs = ['at_clase_I_IA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['at_clase_I_IB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="at_clase_I_IB" id="at_clase_I_IB" <?php echo e($equipo->at_clase_I_IB ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Clase I IB</span>
                            </label>
                            <?php $__errorArgs = ['at_clase_I_IB'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['at_clase_III'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="at_clase_III" id="at_clase_III" <?php echo e($equipo->at_clase_III ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Clase III</span>
                            </label>
                            <?php $__errorArgs = ['at_clase_III'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Clasificación tecnológica</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['ct_mecanica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="ct_mecanica" id="ct_mecanica" <?php echo e($equipo->ct_mecanica ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Mecánica</span>
                            </label>
                            <?php $__errorArgs = ['ct_mecanica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['ct_hidraulica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="ct_hidraulica" id="ct_hidraulica" <?php echo e($equipo->ct_hidraulica ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Hidráulica</span>
                            </label>
                            <?php $__errorArgs = ['ct_hidraulica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['ct_neumatica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="ct_neumatica" id="ct_neumatica" <?php echo e($equipo->ct_neumatica ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Neumática</span>
                            </label>
                            <?php $__errorArgs = ['ct_neumatica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['ct_electrica_electronica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="ct_electrica_electronica" id="ct_electrica_electronica"
                                    <?php echo e($equipo->ct_electrica_electronica ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Eléctrica electrónica</span>
                            </label>
                            <?php $__errorArgs = ['ct_electrica_electronica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Planos</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['p_electricos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="p_electricos" id="p_electricos" <?php echo e($equipo->p_electricos ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Eléctricos</span>
                            </label>
                            <?php $__errorArgs = ['p_electricos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['p_mecanicos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="p_mecanicos" id="p_mecanicos" <?php echo e($equipo->p_mecanicos ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Mecánicos</span>
                            </label>
                            <?php $__errorArgs = ['p_mecanicos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['p_hidraulicos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="p_hidraulicos" id="p_hidraulicos" <?php echo e($equipo->p_hidraulicos ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Hidráulicos</span>
                            </label>
                            <?php $__errorArgs = ['p_hidraulicos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['p_otros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="p_otros" id="p_otros" <?php echo e($equipo->p_otros ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Otros</span>
                            </label>
                            <?php $__errorArgs = ['p_otros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Manuales</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['m_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="m_usuario" id="m_usuario" <?php echo e($equipo->m_usuario ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Usuario</span>
                            </label>
                            <?php $__errorArgs = ['m_usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['m_instalacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="m_instalacion" id="m_instalacion" <?php echo e($equipo->m_instalacion ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Instalación</span>
                            </label>
                            <?php $__errorArgs = ['m_instalacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['m_partes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="m_partes" id="m_partes" <?php echo e($equipo->m_partes ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Partes</span>
                            </label>
                            <?php $__errorArgs = ['m_partes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['m_otros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="m_otros" id="m_otros" <?php echo e($equipo->m_otros ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Otros</span>
                            </label>
                            <?php $__errorArgs = ['m_otros'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Registro evaluación operativa estado funcional</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-8">
                            <label class="form-label" for="text">Estado funcional <span
                                    class="text-danger">*</span></label>
                            <select class="form-control" name="estado_funcional" id="estado_funcional" required>
                                <option value="<?php echo e($equipo->estado_funcional); ?>" selected><?php echo e($equipo->estado_funcional); ?>

                                </option>
                                <?php $__currentLoopData = $estados_funcional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado_funcional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($estado_funcional); ?>">
                                        <?php echo e($estado_funcional); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['estado_funcional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Accesorios</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-2 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['registra_accesorios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="registra_accesorios" id="registra_accesorios"
                                    <?php echo e($equipo->registra_accesorios ? 'checked' : ''); ?>>
                                <span class="form-check-sign"> ¿Registra accesorios?</span>
                            </label>
                            <?php $__errorArgs = ['registra_accesorios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Recomendaciones del fabricante</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-10">
                            <label class="form-label" for="text">Recomendaciones <span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control <?php $__errorArgs = ['rf_recomendaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rf_recomendaciones"
                                id="rf_recomendaciones" value="<?php echo e($equipo->rf_recomendaciones); ?>" required><?php echo e($equipo->rf_recomendaciones); ?></textarea>
                            <?php $__errorArgs = ['rf_recomendaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-10">
                            <label class="form-label" for="text">URL documento adquisición <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control <?php $__errorArgs = ['rf_url_doc_adquisicion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="rf_url_doc_adquisicion" id="rf_url_doc_adquisicion"
                                value="<?php echo e($equipo->rf_url_doc_adquisicion); ?>" required>
                            <?php $__errorArgs = ['rf_url_doc_adquisicion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-5">
                            <label class="form-label" for="text">Fecha instalación <span
                                    class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php $__errorArgs = ['rf_fecha_instalacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="rf_fecha_instalacion" id="rf_fecha_instalacion"
                                value="<?php echo e($equipo->rf_fecha_instalacion); ?>" required>
                            <?php $__errorArgs = ['rf_fecha_instalacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-5">
                            <label class="form-label" for="text">Fecha de operación <span
                                    class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php $__errorArgs = ['rf_fecha_operacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="rf_fecha_operacion" id="rf_fecha_operacion" value="<?php echo e($equipo->rf_fecha_operacion); ?>"
                                required>
                            <?php $__errorArgs = ['rf_fecha_operacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Clasificación biomédica</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['cb_apoyo_lab_clinico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="cb_apoyo_lab_clinico" id="cb_apoyo_lab_clinico"
                                    <?php echo e($equipo->cb_apoyo_lab_clinico ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Apoyo / lab. clínico</span>
                            </label>
                            <?php $__errorArgs = ['cb_apoyo_lab_clinico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['cb_diagnostico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="cb_diagnostico" id="cb_diagnostico"
                                    <?php echo e($equipo->cb_diagnostico ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Diagnóstico</span>
                            </label>
                            <?php $__errorArgs = ['cb_diagnostico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['cb_soporte_mto_vida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="cb_soporte_mto_vida" id="cb_soporte_mto_vida"
                                    <?php echo e($equipo->cb_soporte_mto_vida ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Soporte / Mto. de vida</span>
                            </label>
                            <?php $__errorArgs = ['cb_soporte_mto_vida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['cb_rehabilitacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="cb_rehabilitacion" id="cb_rehabilitacion"
                                    <?php echo e($equipo->cb_rehabilitacion ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Rehabilitación</span>
                            </label>
                            <?php $__errorArgs = ['cb_rehabilitacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input <?php $__errorArgs = ['cb_prevencion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="cb_prevencion" id="cb_prevencion" <?php echo e($equipo->cb_prevencion ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Prevención</span>
                            </label>
                            <?php $__errorArgs = ['cb_prevencion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Mantenimiento</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-3 d-flex align-items-center mt-4">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['mant_preventivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="mant_preventivo" id="mant_preventivo"
                                    <?php echo e($equipo->mant_preventivo ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Mantenimiento preventivo</span>
                            </label>
                            <?php $__errorArgs = ['mant_preventivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-3 d-flex align-items-center mt-4">
                            <label class="form-check-label">
                                <input type="checkbox"
                                    class="form-check-input <?php $__errorArgs = ['mant_correctivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="mant_correctivo" id="mant_correctivo"
                                    <?php echo e($equipo->mant_correctivo ? 'checked' : ''); ?>>
                                <span class="form-check-sign">Mantenimiento correctivo</span>
                            </label>
                            <?php $__errorArgs = ['mant_correctivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-3">
                            <label class="form-label" for="text">Validación mantenimiento <span
                                    class="text-danger">*</span></label>
                            <select class="form-control" name="mant_validacion" id="mant_validacion" required>
                                <option value="<?php echo e($equipo->mant_validacion); ?>" selected><?php echo e($equipo->mant_validacion); ?>

                                </option>
                                <?php $__currentLoopData = $mants_validacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mant_validacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mant_validacion); ?>">
                                        <?php echo e($mant_validacion); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['mant_validacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="mt-4 d-flex justify-content-between mx-2">
                        <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-default col-5" type="button">
                            <i class="la icon-close mr-2"></i> Cancelar
                        </a>

                        <button class="btn btn-success col-5" type="submit">
                            <i class="la icon-check mr-2"></i> Actualizar
                        </button>
                    </div>
                </form>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
    <script>
        function cambiarEstadoSelectFrecCalibracion() {
            var checkboxCalibracion = document.getElementById('calibracion');
            var selectFrecCalibracion = document.getElementById('frecuencia_calibracion');
            selectFrecCalibracion.disabled = !checkboxCalibracion.checked;
        }
        /* municipalities */
        $("#departamento_id").on('change', function() {
            $("#municipio_id").empty();
            if ($(this).val().length == 0) {
                return false;
            } else {
                $("#municipio_id")
                    .addClass('fas fa-spinner')
                    .load($("#municipio_id").attr('src').replace('#', $(this).val()), function() {
                        $("#municipio_id").prepend($("<option/>").attr({
                                selected: true,
                                disabled: true
                            }).html('Seleccione municipio'))
                            .removeClass('fas fa-spinner')
                    });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/equipos/edit.blade.php ENDPATH**/ ?>