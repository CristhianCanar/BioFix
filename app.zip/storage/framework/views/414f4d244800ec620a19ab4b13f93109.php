<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="col-10 mt-4 mx-auto">
            <?php $__env->startComponent('components.card-form', ['title' => 'Detalles responsable mantenimiento']); ?>
                <div class="form-group">
                    <label class="form-label" for="departamento_id">Identificación</label>
                    <p><?php echo e($responsableMantenimiento->identificacion); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="municipio_id">Nombres</label>
                    <p><?php echo e($responsableMantenimiento->nombre); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Apellidos</label>
                    <p><?php echo e($responsableMantenimiento->apellido); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Telefono</label>
                    <p><?php echo e($responsableMantenimiento->telefono); ?></p>
                </div>

                <div class="form-group">
                    <label class="form-label" for="text">Cargo</label>
                    <p><?php echo e($responsableMantenimiento->cargo); ?></p>
                </div>

                <div class="form-group mt-4 mx-auto">
                    <a href="<?php echo e(route('responsables_mantenimientos.index')); ?>" class="btn btn-default btn-block"><i class="la icon-logout mr-3"></i>Regresar</a>
                </div>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/responsables_mantenimientos/show.blade.php ENDPATH**/ ?>