<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <h1 class="text-center"><b>Detalles de mantenimientos</b></h1>
        <?php $__currentLoopData = $mantenimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mantenimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-10 mt-4 mx-auto">
                <?php $__env->startComponent('components.card-form', ['title' => 'Mantenimiento N°' . $loop->iteration]); ?>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12">
                            <label class="form-label" for="text">
                                Equipo ( Serie - Nombre - Modelo )
                            </label>
                            <p><?php echo e($mantenimiento->equipos->serie); ?> - <?php echo e($mantenimiento->equipos->nombre); ?> -
                                <?php echo e($mantenimiento->equipos->modelo); ?></p>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">
                                Fecha mantenimiento
                            </label>
                            <p> <?php echo e($mantenimiento->fecha_mantenimiento); ?> </p>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center mt-4">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->retiro_equipo_IPS ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">¿Retiro equipo de IPS?</span>
                            </label>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center mt-4">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->equipo_funcionando ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">¿El equipo queda en funcionamiento?</span>
                            </label>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Verificación de bioseguridad</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-8 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->vb_pregunta_uno ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿El equipo médico se entrega limpio y desinfectado para realizar
                                    la actividad de mantenimiento?
                                </span>
                            </label>
                        </div>
                        <div class="form-check col-12 col-md-8 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->vb_pregunta_dos ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿El mantenimiento cuenta con los implementos de dotación necesarios para garantizar la
                                    seguridad?
                                </span>
                            </label>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Repuestos</b></h2>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <?php $__currentLoopData = $mantenimiento->repuestos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repuesto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-row justify-content-center repuesto">
                                    <div class="form-group col-3 col-md-3">
                                        <label class="form-label" for="text">
                                            Fecha reporte
                                        </label>
                                        <input type="date" class="form-control" value="<?php echo e($repuesto['fecha_reporte']); ?>"
                                            disabled>
                                    </div>
                                    <div class="form-group col-4 col-md-3">
                                        <label class="form-label" for="text">
                                            Nombre repuesto
                                        </label>
                                        <input type="text" class="form-control" value="<?php echo e($repuesto['repuesto']); ?>" disabled>
                                    </div>
                                    <div class="form-group col-4 col-md-3">
                                        <label class="form-label" for="text">
                                            Nombre proveedor
                                        </label>
                                        <input type="text" class="form-control" value="<?php echo e($repuesto['proveedor']); ?>"
                                            disabled>
                                    </div>
                                    <div class="form-group col-2 col-md-3">
                                        <label class="form-label" for="text">
                                            Cantidad
                                        </label>
                                        <input type="number" class="form-control" value="<?php echo e($repuesto['cantidad']); ?>"
                                            disabled>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center  mt-4">
                        <h2><b>Verificación de funcionamiento</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->vf_carcasa ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿El equipo tiene carcasa?
                                </span>
                            </label>
                        </div>
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->vf_etiquetado ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿El equipo tiene etiquetado?
                                </span>
                            </label>
                        </div>
                        <div class="form-check col-12 col-md-3 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->vf_estructura_soporte ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿El equipo tiene estructura de soporte?
                                </span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->vf_integridad_rosca_tapa ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿La integridad de la rosca es correcta?
                                </span>
                            </label>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->vf_revision_limpieza_tanque ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿Revisión de la limpieza de tanque?
                                </span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->vf_revision_fuga_gas ? 'checked' : ''); ?> disabled>
                            </label>
                            <?php $__errorArgs = ['vf_revision_fuga_gas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->vf_condicion_entorno ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿Condiciones de entorno (Humedad, temperatura)?
                                </span>
                            </label>
                        </div>
                    </div>

                    
                    <div class="form-row justify-content-center">
                        <h2><b>Mantenimiento</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->m_limpieza_externa ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿Limpieza externa?
                                </span>
                            </label>
                        </div>
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->m_limpieza_interna ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿Limpieza interna?
                                </span>
                            </label>
                        </div>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-check col-12 col-md-4 d-flex align-items-center">
                            <label class="form-check-label">
                                <input type="checkbox" class="form-check-input"
                                    <?php echo e($mantenimiento->m_ajustes ? 'checked' : ''); ?> disabled>
                                <span class="form-check-sign">
                                    ¿Ajustes?
                                </span>
                            </label>
                        </div>
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="text">Tiempo usado (minutos)</label>
                            <p><?php echo e($mantenimiento->m_tiempo_usado); ?></p>
                        </div>
                    </div>

                    <div class="form-row justify-content-center">
                        <h2><b>Responsable</b></h2>
                    </div>
                    <div class="form-row justify-content-center">
                        <p><b>Quien recibe y compromete a realizar la actividad necesaria para que el equipo este limpio y
                                desinfectado</b></p>
                    </div>
                    <div class="form-row justify-content-center">
                        <div class="form-group col-12">
                            <label class="form-label" for="text">Responsable (Nombres Apellidos)</label>
                            <p><?php echo e($mantenimiento->responsables->nombre); ?> <?php echo e($mantenimiento->responsables->apellido); ?></p>
                        </div>
                    </div>
                <?php echo $__env->renderComponent(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group col-10 mt-4 mx-auto">
            <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-default btn-block"><i
                    class="la icon-logout mr-3"></i>Regresar</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/mantenimientos/show.blade.php ENDPATH**/ ?>