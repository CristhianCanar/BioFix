<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="col-10 mt-4 mx-auto">
            <?php $__env->startComponent('components.card-form', ['title' => 'Registrar baja de equipo', 'show' => false]); ?>
                <form action="<?php echo e(route('unsubscribe.store', ['equipoId' => $equipo->id])); ?>" method="POST"
                    enctype="multipart/form-data" class="needs-validation" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="form-row justify-content-center">
                        <h2><b>Datos básicos</b></h2>
                    </div>
                    <div class="form-group">
                        <h4><b>Datos del equipo</b></h4>
                        <div class="row justify-content-around">
                            <div>
                                <strong class="text-dark">Nombre:</strong>
                                <p class="text-muted"><?php echo e($equipo->nombre); ?></p>
                            </div>
                            <div>
                                <strong class="text-dark">Serie:</strong>
                                <p class="text-muted"><?php echo e($equipo->serie); ?></p>
                            </div>
                            <div>
                                <strong class="text-dark">Modelo:</strong>
                                <p class="text-muted"><?php echo e($equipo->modelo); ?></p>
                            </div>
                            <div>
                                <strong class="text-dark">Marca:</strong>
                                <p class="text-muted"><?php echo e($equipo->marca); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="form-group col-md-6 col-12">
                            <label class="form-label" for="baja_fecha">Fecha de baja <span class="text-danger">*</span></label>
                            <input type="date" class="form-control <?php $__errorArgs = ['baja_fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="baja_fecha" id="baja_fecha" value="<?php echo e(old('baja_fecha')); ?>" maxlength="50" required>

                            <?php $__errorArgs = ['baja_fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-md-6 col-12">
                            <label class="form-label" for="baja_motivo">Motivo de baja <span
                                    class="text-danger">*</span></label>
                            <select class="form-control" name="baja_motivo" id="baja_motivo" required>
                                <option value="" selected disabled>Seleccione...</option>
                                <?php $__currentLoopData = $bajaMotivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bajaMotivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($bajaMotivo); ?>">
                                        <?php echo e($bajaMotivo); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['baja_motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="text">Evaluación técnica <span class="text-danger">*</span></label>
                        <textarea class="form-control <?php $__errorArgs = ['evaluacion_tecnica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="evaluacion_tecnica"
                            id="evaluacion_tecnica" value="<?php echo e(old('evaluacion_tecnica')); ?>" required><?php echo e(old('evaluacion_tecnica')); ?></textarea>

                        <?php $__errorArgs = ['evaluacion_tecnica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="text">Evaluación clinica <span class="text-danger">*</span></label>
                        <textarea class="form-control <?php $__errorArgs = ['evaluacion_clinica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="evaluacion_clinica"
                            id="evaluacion_clinica" value="<?php echo e(old('evaluacion_clinica')); ?>" required><?php echo e(old('evaluacion_clinica')); ?></textarea>

                        <?php $__errorArgs = ['evaluacion_clinica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="text">Observaciones <span class="text-danger">*</span></label>
                        <textarea class="form-control <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="observaciones" id="observaciones"
                            value="<?php echo e(old('observaciones')); ?>" required><?php echo e(old('observaciones')); ?></textarea>

                        <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="text">Cláusula <span class="text-danger">*</span></label>
                        <textarea class="form-control <?php $__errorArgs = ['clausula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="clausula" id="clausula"
                            value="<?php echo e(old('clausula')); ?>" required><?php echo e(old('clausula')); ?></textarea>

                        <?php $__errorArgs = ['clausula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mt-4 d-flex justify-content-between mx-2">
                        <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-default col-5" type="button">
                            <i class="la icon-close mr-2"></i> Cancelar
                        </a>

                        <button class="btn btn-success col-5" type="submit">
                            <i class="la icon-check mr-2"></i> Registrar
                        </button>
                    </div>
                </form>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/dar_de_baja_equipos/register.blade.php ENDPATH**/ ?>