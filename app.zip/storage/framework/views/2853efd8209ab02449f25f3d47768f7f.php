<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <h1 class="text-center"><b>Gestionar empresas</b></h1>
        <div class="mt-4">
            <?php $__env->startComponent('components.table'); ?>
                <?php $__env->slot('thead'); ?>
                    <th>N°</th>
                    <th scope="col">NIT</th>
                    <th scope="col">Razón social</th>
                    <th scope="col">Teléfono</th>
                    <th scope="col" class="text-right">Acciones</th>
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('tbody'); ?>
                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td class="text-truncate"><?php echo e($empresa->nit); ?></td>
                            <td class="text-truncate"><?php echo e($empresa->razon_social); ?></td>
                            <td class="text-truncate"><?php echo e($empresa->telefono); ?></td>
                            <td>
                                <div class="row float-right justify-content-end" style="font-size: 20px">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresas_editar')): ?>
                                        <div class="col-3">
                                            <a href="<?php echo e(route('empresas.edit', $empresa->id)); ?>"
                                                style="color: #5C55BF;">
                                                <i class="la icon-note" data-toggle="tooltip"
                                                    title="Editar empresa"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-3">
                                        <a href="<?php echo e(route('empresas.show', $empresa->id)); ?>"
                                            style="color: #fa8c15;">
                                            <i class="la icon-eye" data-toggle="tooltip"
                                                title="Ver empresa"></i>
                                        </a>
                                    </div>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('empresas_eliminar')): ?>
                                        <div class="col-3 mr-1">
                                            <form action="<?php echo e(route('empresas.destroy', $empresa->id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-light bg-inherit p-0"
                                                    onclick="return confirm('Seguro que desea eliminar el registro del empresa?')">
                                                    <i class="la icon-trash" data-toggle="tooltip"
                                                        data-placement="top" title="Eliminar empresa"
                                                        style="font-size: 20px; color: #f44336;"></i>
                                                </button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->endSlot(); ?>
                <span> Total registros <b><?php echo e($empresas->total()); ?></b></span>
                <span class="float-right"><?php echo e($empresas->links()); ?></span>
            <?php echo $__env->renderComponent(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\faber\BioFix\resources\views/admin/empresas/manage.blade.php ENDPATH**/ ?>